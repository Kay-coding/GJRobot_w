package com.guojia.robot.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.guojia.robot.R;
import com.guojia.robot.iflytek.FaceManager;
import com.guojia.robot.utils.ToastUtil;

import java.io.File;

/**
 * Created by win7 on 2017/10/26.
 */

public class FaceActivity extends BaseActivity implements View.OnClickListener {
    private ImageView mImage_iv;
    private Button regist_btn,verify_btn,camera_btn;
    private String mAutherID;
    private FaceManager mFaceManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_ver_layout);
        initView();
        handleData();
    }

    private void handleData() {
        Intent intent = getIntent();
        mAutherID = intent.getStringExtra("accountID");
        mFaceManager = new FaceManager(this,mAutherID,mImage_iv);
        resultListener = mFaceManager.getListenerInstance();
    }

    private void initView() {
        mImage_iv = findViewById(R.id.online_img);
        regist_btn = findViewById(R.id.online_reg);
        verify_btn = findViewById(R.id.online_verify);
//        pick_btn = findViewById(R.id.online_pick);
        camera_btn = findViewById(R.id.online_camera);

        verify_btn.setOnClickListener(this);
        regist_btn.setOnClickListener(this);
        camera_btn.setOnClickListener(this);
//        pick_btn.setOnClickListener(this);
        mImage_iv.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
//            case R.id.online_pick:
//                break;
            case R.id.online_reg:
                mFaceManager.regist();
                break;
            case R.id.online_verify:
                mFaceManager.verfify();
                break;
            case R.id.online_camera:
                mFaceManager.camera();
                break;
            case R.id.online_img:
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_PICK);
                startActivityForResult(intent, FaceManager.REQUEST_PICTURE_CHOOSE);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        resultListener.handleActivityCode(requestCode,resultCode,data);
    }

    private  ActivityResultListener resultListener;


    public interface ActivityResultListener{
       void handleActivityCode(int requestCode,int resultCode,Intent data);
    }
}
